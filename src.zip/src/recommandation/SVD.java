package recommandation;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.common.Weighting;
import org.apache.mahout.cf.taste.eval.RecommenderBuilder;
import org.apache.mahout.cf.taste.eval.RecommenderEvaluator;
import org.apache.mahout.cf.taste.impl.eval.AverageAbsoluteDifferenceRecommenderEvaluator;
import org.apache.mahout.cf.taste.impl.eval.RMSRecommenderEvaluator;
import org.apache.mahout.cf.taste.impl.model.file.FileDataModel;
import org.apache.mahout.cf.taste.impl.neighborhood.ThresholdUserNeighborhood;
import org.apache.mahout.cf.taste.impl.recommender.GenericUserBasedRecommender;
import org.apache.mahout.cf.taste.impl.recommender.svd.ALSWRFactorizer;
import org.apache.mahout.cf.taste.impl.recommender.svd.ParallelSGDFactorizer;
import org.apache.mahout.cf.taste.impl.recommender.svd.SVDRecommender;
import org.apache.mahout.cf.taste.impl.similarity.EuclideanDistanceSimilarity;
import org.apache.mahout.cf.taste.impl.similarity.PearsonCorrelationSimilarity;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.neighborhood.UserNeighborhood;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.recommender.Recommender;
import org.apache.mahout.cf.taste.similarity.ItemSimilarity;
import org.apache.mahout.cf.taste.similarity.UserSimilarity;

import java.io.File;
import java.io.IOException;
import java.util.List;

import static recommandation.FXMLDocumentController.*;

/**
 * Created by hichem on 2017-05-14.
 */
public class SVD {
    public static double result;

    public  static ObservableList<dataInfo> data = FXCollections.observableArrayList();
    public ObservableList<dataInfo> getItem(){
        return data;
    }

    public double getEval(){
        return result;
    }
    public double getrmsEval(){
        return score11;
    }

    public static double score11;
    public static String typeFactorizer=ComboboxAlgoFx11.getValue();
    public void test() throws IOException, TasteException{
        DataModel model = new FileDataModel(new File(pathh));





        ALSWRFactorizer factorizer = new ALSWRFactorizer(model, 50, 0.065, 15);
        ParallelSGDFactorizer factorizer2 = new ParallelSGDFactorizer(model,10,0.1,1);
        SVDRecommender recommender;
        if(typeFactorizer == "ParallelSGDFactorizer")
             recommender = new SVDRecommender(model, factorizer);
        else
             recommender = new SVDRecommender(model, factorizer2);

        // GenericItemBasedRecommender recommender = new GenericItemBasedRecommender(model,similarity);
        Long i= Long.valueOf(ComboBoxAlgFx11.getValue());
        int Nbr=Integer.valueOf(nbrRecomFx11.getText());

        List<RecommendedItem> recommendations = recommender.recommend(i,Nbr);
        for (RecommendedItem recommendation : recommendations) {
            System.out.println(recommendation);
            data.add(new dataInfo(ComboBoxAlgFx11.getValue(), recommendation.getItemID()+"", recommendation.getValue()+""));

        }
    }





}








